package com.cathay.xx.zx.module.test;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.log4j.Logger;

import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.util.AuthUtil;
import com.cathay.common.util.DATE;
import com.cathay.util.DBTestCase;
import com.cathay.xx.vo.DTXXTP01;
import com.cathay.xx.zx.module.XX_ZX0100;

@SuppressWarnings("unchecked")
public class XX_ZX0100Test extends DBTestCase {
    private static final Logger log = Logger.getLogger(XX_ZX0100Test.class);

    /** Log4j�O�_��Debug�Ҧ� */
    private boolean isDebug = log.isDebugEnabled();

    public XX_ZX0100Test(String arg) {
        super(arg);
    }

    protected void setUp() throws Exception {
        super.setUp();  //before test
    }

    protected void tearDown() throws Exception {
        super.tearDown();  //after test
    }


    public void testQuery() {

        log.debug("==query=���V1.==");

        try {
            Map myMap = new HashMap();
            myMap.put("EMP_ID", "D123456781");
            myMap.put("DIV_NO", "9400000");
            new XX_ZX0100().query(myMap);
            log.debug("==query=���V1.=���\=");
        } catch (Exception e) {
            log.debug("==query=���V1.=����=", e);
            fail();
        }


        log.debug("==query=���V1.==");

        try {
            Map myMap = new HashMap();
            myMap.put("EMP_ID", "D123456781");
//            myMap.put("DIV_NO", "9400000");
            new XX_ZX0100().query(myMap);
            log.debug("==query=���V1.=���\=");
        } catch (Exception e) {
            log.debug("==query=���V1.=����=", e);
            fail();
        }
        
        
        log.debug("==query=���V1.==");

        try {
            Map myMap = new HashMap();
//            myMap.put("EMP_ID", "D123456781");
            myMap.put("DIV_NO", "9400000");
            new XX_ZX0100().query(myMap);
            log.debug("==query=���V1.=���\=");
        } catch (Exception e) {
            log.debug("==query=���V1.=����=", e);
            fail();
        }
        
        log.debug("==query=���V1.==");

        try {
            Map myMap = new HashMap();
//            myMap.put("EMP_ID", "D123456781");
//            myMap.put("DIV_NO", "9400000");
            new XX_ZX0100().query(myMap);
            log.debug("==query=���V1.=���\=");
        } catch (Exception e) {
            log.debug("==query=���V1.=����=", e);
            fail();
        }
        /*
               log.debug("==query=�t�V1.==");
                try {
                    
                    new XX_ZX0100().query(null);
                    log.debug("==query=�t�V1.=����=");
                    fail();
                } catch (ErrorInputException eie) {
                    log.debug("==query=�t�V1.=���\=");

                } catch (Exception e) {
                    log.debug("==query=�t�V1.=����=");
                    fail();
                }*/
    }
//    "EMP_ID"    ,"EMP_NAME","DIV_NO" ,"BIRTHDAY"  ,"POSITION","UPDT_ID"   ,"UPDT_NM","UPDT_DATE"                 ,"DIV_NO_NM"
//    "D123456780","���T"     ,"9400000","2016-08-02","�M��"     ,"B28897451E","�š���"   ,"2017-08-29-17.43.47.943686","��P��T��"
//    "a115800000","���T"     ,"9400000","2016-08-02","�M��"     ,"L18973609G","�i����"   ,"2017-08-31-17.24.31.893000","��P��T��"
//    "BIRTHDAY","EMP_ID","EMP_NAME","DIV_NO","BIRTHDAY1","POSITION","UPDT_ID","UPDT_NM","UPDT_DATE","DIV_NO_NM"
//    "2016-08-02","D123456780","���T","9400000","2016-08-02","�M��","B28897451E","�š���","2017-08-29-17.43.47.943686","��P��T��"

    public void testInsert() {
//        fail("�|����@");
        log.debug("==query=���V2.==");
        try {
            UserObject user = new AuthUtil().getUserObjByID("B28897451E");  //G18768951J//set up a connetcion
            System.err.println("user:"+user);
            
            Map myMap = new HashMap();
            myMap.put("EMP_ID", "D123456780");
            myMap.put("EMP_NAME", "���T");
            myMap.put("DIV_NO", "9400000");
            myMap.put("BIRTHDAY", "2016-08-02");
            myMap.put("POSITION", "�M��");
            myMap.put("UPDT_ID", "B28897451E");
            myMap.put("UPDT_DATE", "2017-08-29-17.43.47.943686");
            myMap.put("OP_STATUS", "10");
            
//            String FLOW_NO = new RZ_N0Z001().startFlow("XXZX0101", "�s�W", "", "D123456780", user.getDivNo());
//            myMap.put("FLOW_NO", FLOW_NO); //"XXZX-0004623041"
            
            new XX_ZX0100().insert(myMap, user);
            log.debug("==query=���V2.=���\=");
        } catch (Exception e) {
            log.debug("==query=���V2.=����=", e);
            fail();
        }
        
        
        log.debug("==query=�t�V2.==");
        try {   
            
            new XX_ZX0100().insert(null, null);
            log.debug("==query=�t�V2.=����=");
            fail();
        } catch (ErrorInputException eie) {
            log.debug("==query=�t�V2.=���\=");

        } catch (Exception e) {
            log.debug("==query=�t�V2.=����=");
            fail();
        }
        
        
        log.debug("==query=�t�V2.==EMP_ID");
        try {
            Map myMap = new HashMap();
//            myMap.put("EMP_ID", "D123456780");
            myMap.put("EMP_NAME", "���T");
            myMap.put("DIV_NO", "9400000");
            myMap.put("BIRTHDAY", "2016-08-02");
            myMap.put("POSITION", "�M��");
            myMap.put("UPDT_ID", "B28897451E");
            myMap.put("UPDT_DATE", "2017-08-29-17.43.47.943686");
            myMap.put("OP_STATUS", "10");
            
            UserObject user = new AuthUtil().getUserObjByID("B28897451E");  //G18768951J//set up a connetcion
            
            new XX_ZX0100().insert(myMap, user);
            log.debug("==query=�t�V2.=����=");
            fail();
        } catch (ErrorInputException eie) {
            log.debug("==query=�t�V2.=���\=");

        } catch (Exception e) {
            log.debug("==query=�t�V2.=����=");
            fail();
        }
        
        log.debug("==query=�t�V2.==�ͤ����榡���~");
        try {
          Map myMap = new HashMap();
          myMap.put("EMP_ID", "D123456780");
          myMap.put("EMP_NAME", "���T");
          myMap.put("DIV_NO", "9400000");
          myMap.put("BIRTHDAY", "2016/08/02");
          myMap.put("POSITION", "�M��");
          myMap.put("UPDT_ID", "B28897451E");
          myMap.put("UPDT_DATE", "2017-08-29-17.43.47.943686");
          myMap.put("OP_STATUS", "10");
          
          UserObject user = new AuthUtil().getUserObjByID("B28897451E");  //G18768951J//set up a connetcion
          
          new XX_ZX0100().insert(myMap, user);
            
            log.debug("==query=�t�V2.=����=");
            fail();
        } catch (ErrorInputException eie) {
            log.debug("==query=�t�V2.=���\=");

        } catch (Exception e) {
            log.debug("==query=�t�V2.=����=");
            fail();
        }
        
    }

    public void testUpdate() {
        
        log.debug("==query=���V3.==");
        
        try {
            UserObject user = new AuthUtil().getUserObjByID("B28897451E");  //G18768951J//set up a connetcion
            System.err.println("user:"+user);

            Map myMap = new HashMap();
            myMap.put("BIRTHDAY", "2016-08-02"); //"2016-08-02"
            myMap.put("EMP_NAME", "���T");
            myMap.put("DIV_NO", "9400000");
            myMap.put("POSITION", "�M��");
//            myMap.put("UPDT_ID", "B28897451E");  
//            myMap.put("UPDT_DATE", "2017-08-30-17.43.47.943686");
            myMap.put("EMP_ID", "D123456780");
            System.err.println("myMap:"+myMap);
            new XX_ZX0100().update(myMap, user);
            log.debug("==query=���V3.=���\=");
        } catch (Exception e) {
            log.debug("==query=���V3.=����=", e);
            fail();
        }
        
        log.debug("==query=�t�V3.==");
        try {
            Map myMap = new HashMap();
            myMap.put("BIRTHDAY", "2016-08-02"); //"2016-08-02"
            myMap.put("EMP_NAME", "���T");
            myMap.put("DIV_NO", "9400000");
            myMap.put("POSITION", "�M��");
            myMap.put("EMP_ID", "D123456780");
            
            new XX_ZX0100().update(null, null);
            log.debug("==query=�t�V3.=����=");
            fail();
        } catch (ErrorInputException eie) {
            log.debug("==query=�t�V3.=���\=");

        } catch (Exception e) {
            log.debug("==query=�t�V3.=����=");
            fail();
        }
        
        log.debug("==query=�t�V3.==EMP_ID");
        try {
            Map myMap = new HashMap();
            myMap.put("BIRTHDAY", "2016-08-02"); //"2016-08-02"
            myMap.put("EMP_NAME", "���T");
            myMap.put("DIV_NO", "9400000");
            myMap.put("POSITION", "�M��");
//            myMap.put("EMP_ID", "D123456780");
            
            
            new XX_ZX0100().update(myMap, null);
            log.debug("==query=�t�V3.=����=");
            fail();
        } catch (ErrorInputException eie) {
            log.debug("==query=�t�V3.=���\=");

        } catch (Exception e) {
            log.debug("==query=�t�V3.=����=");
            fail();
        }
        
        log.debug("==query=�t�V3.==�ͤ����榡���~");
        try {
            Map myMap = new HashMap();
            myMap.put("BIRTHDAY", "2016/08/02"); //"2016-08-02"
            myMap.put("EMP_NAME", "���T");
            myMap.put("DIV_NO", "9400000");
            myMap.put("POSITION", "�M��");
            myMap.put("EMP_ID", "D123456780");
            
            new XX_ZX0100().update(myMap, null);
            log.debug("==query=�t�V3.=����=");
            fail();
        } catch (ErrorInputException eie) {
            log.debug("==query=�t�V3.=���\=");

        } catch (Exception e) {
            log.debug("==query=�t�V3.=����=");
            fail();
        }
    }

    public void testDelete() {
        
        log.debug("==query=���V4.==");
        try {
            
            Map myMap = new HashMap();
            myMap.put("EMP_ID", "D123456780");

            new XX_ZX0100().delete( MapUtils.getString(myMap, "EMP_ID") );
            log.debug("==query=���V4.=���\=");
        } catch (Exception e) {
            log.debug("==query=���V4.=����=", e);
            fail();
        }
        
        log.debug("==query=�t�V4.==");
        try {
            
            new XX_ZX0100().delete(null);
            log.debug("==query=�t�V4.=����=");
            fail();
        } catch (ErrorInputException eie) {
            log.debug("==query=�t�V4.=���\=");

        } catch (Exception e) {
            log.debug("==query=�t�V4.=����=");
            fail();
        }
    }

    public void testConfirm() {
        log.debug("==query=���V5.==");
        try {
            
            Map myMap = new HashMap();
            myMap.put("EMP_ID", "D123456780");
            
            DTXXTP01 vo = new DTXXTP01(); 
            vo.setEMP_ID("D123456781");
//            vo.setOP_STATUS(20);
            
            new XX_ZX0100().confirm( vo );
            log.debug("==query=���V5.=���\=");
        } catch (Exception e) {
            log.debug("==query=���V5.=����=", e);
            fail();
        }
        
        log.debug("==query=�t�V5.==");
        try {
            
            new XX_ZX0100().confirm(null);
            log.debug("==query=�t�V5.=����=");
            fail();
        } catch (ErrorInputException eie) {
            log.debug("==query=�t�V5.=���\=");

        } catch (Exception e) {
            log.debug("==query=�t�V5.=����=");
            fail();
        }
    }

    public void testReject() {
        log.debug("==query=���V6.==");
        try {
            
            Map myMap = new HashMap();
            myMap.put("EMP_ID", "D123456780");
            
            DTXXTP01 vo = new DTXXTP01(); 
            vo.setEMP_ID("D123456781");
//            vo.setOP_STATUS(10);
            
            new XX_ZX0100().reject( vo );
            log.debug("==query=���V6.=���\=");
        } catch (Exception e) {
            log.debug("==query=���V6.=����=", e);
            fail();
        }
        
        log.debug("==query=�t�V6.==");
        try {
            
            new XX_ZX0100().reject(null);
            log.debug("==query=�t�V6.=����=");
            fail();
        } catch (ErrorInputException eie) {
            log.debug("==query=�t�V6.=���\=");

        } catch (Exception e) {
            log.debug("==query=�t�V6.=����=");
            fail();
        }
    }

    public void testApprove() {
        log.debug("==query=���V7.==");
        try {
            
            Map myMap = new HashMap();
            myMap.put("EMP_ID", "D123456780");
            
            DTXXTP01 vo = new DTXXTP01(); 
            vo.setEMP_ID("D123456781");
//            vo.setOP_STATUS(30);
            
            new XX_ZX0100().approve( vo );
            log.debug("==query=���V7.=���\=");
        } catch (Exception e) {
            log.debug("==query=���V7.=����=", e);
            fail();
        }
        
        log.debug("==query=�t�V7.==");
        try {
            
            new XX_ZX0100().approve(null);
            log.debug("==query=�t�V7.=����=");
            fail();
        } catch (ErrorInputException eie) {
            log.debug("==query=�t�V7.=���\=");

        } catch (Exception e) {
            log.debug("==query=�t�V7.=����=");
            fail();
        }
    }

}
