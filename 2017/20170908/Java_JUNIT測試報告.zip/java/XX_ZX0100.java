package com.cathay.xx.zx.module;

import java.sql.Timestamp;
import java.util.Calendar;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;

import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.util.DATE;
import com.cathay.common.util.db.DBUtil;
import com.cathay.rz.n0.module.RZ_N0Z001;
import com.cathay.util.Transaction;
import com.cathay.xx.vo.DTXXTP01;
import com.igsapp.db.DataSet;

/**
 * <pre>
 * DATE Version Description Author
 * 2012/11/22  1.0 Create  �i����
 * 
 * �@�B  �{���\�෧�n�����G
 * �ҲզW��    ���u�򥻸�Ƭd�߼Ҳ�
 * �Ҳ�ID    XX_ZX0100
 * ���n����    ���u�򥻸�Ƭd�߼Ҳ�
 * </pre>
 * 
 * @author �L����
 * @since 2017/9/4
 * 
 */
@SuppressWarnings("unchecked")
public class XX_ZX0100 {

    private static final String SQL_insert_001 = "com.cathay.xx.zx.module.XX_ZX0100.SQL_insert_001";

    private static final String SQL_update_001 = "com.cathay.xx.zx.module.XX_ZX0100.SQL_update_001";

    private static final String SQL_query_001 = "com.cathay.xx.zx.module.XX_ZX0100.SQL_query_001";

    private static final String SQL_delete_001 = "com.cathay.xx.zx.module.XX_ZX0100.SQL_delete_001";

//    private static final String SQL_confirm_001 = "com.cathay.xx.zx.module.XX_ZX0100.SQL_confirm_001";
//
//    private static final String SQL_reject_0101 = "com.cathay.xx.zx.module.XX_ZX0100.SQL_reject_0101";
//
//    private static final String SQL_approve_001 = "com.cathay.xx.zx.module.XX_ZX0100.SQL_approve_001";

    /**
     * �d�߭��u�򥻸��
     * @param reqMap
     * <pre>
     * EMP_ID : ���u�s��
     * DIV_NO : ���N��(LIKE�ҽk�d��)
     * </pre>
     * @return rtnList  List<Map> ���u�򥻸����
     * @throws ModuleException 
     */
    public List<Map> query(Map reqMap) throws ModuleException {
        /*ErrorInputException eie = null;

        if (reqMap == null || reqMap.isEmpty()) {
            throw getErrorInputException(eie, "�򥻸�Ƥ��o����");
        }
        String EMP_ID = MapUtils.getString(reqMap, "EMP_ID");
        if (StringUtils.isBlank(EMP_ID)) {
            eie = getErrorInputException(eie, "���u�s�����o����");
        }
        String BIRTHDAY = MapUtils.getString(reqMap, "BIRTHDAY");
        if (StringUtils.isNotBlank(BIRTHDAY) && !DATE.isDate(BIRTHDAY)) {
            eie = getErrorInputException(eie, "�ͤ����榡���~");
        }
        if (eie != null) {
            throw eie;
        }*/

        DataSet ds = Transaction.getDataSet();
        if (reqMap != null && !reqMap.isEmpty()) {
            String EMP_ID = MapUtils.getString(reqMap, "EMP_ID");
            if (StringUtils.isNotEmpty(EMP_ID)) {
                ds.setField("EMP_ID", EMP_ID);
            }
            String DIV_NO = MapUtils.getString(reqMap, "DIV_NO");
            if (StringUtils.isNotEmpty(DIV_NO)) {
                StringBuilder sb = new StringBuilder();
                sb.append('%').append(DIV_NO).append('%');
                ds.setField("DIV_NO", sb.toString());
            }
        }
        /*DBUtil.searchAndRetrieve(ds, SQL_query_001);
        List<Map> rtnList = new ArrayList<Map>();
        while (ds.next()) {
            Map map = VOTool.dataSetToMap(ds);
            rtnList.add(map);
        }*/
        
        List<Map> rtnList = VOTool.findToMaps(ds, SQL_query_001);
        //List<DTXXTP01> TP01List = VOTool.findToVOs(DTXXTP01.class, ds, SQL_query_001);

        //���o�f�媬�A����
        new RZ_N0Z001().putOP_STATUS_NM(rtnList, "XXZX0101");

        return rtnList;
    }

    /**
     * �s�W�򥻸��
     * @param reqMap
     * @param user
     * <pre>
     * �s�W�򥻸��
     * EMP_ID�G���u�s��
     * DIV_NO�G���N��
     * EMP_NAME�G���u�m�W
     * BIRTHDAY�G�ͤ���
     * POSITION�G¾��
     * </pre>
     * @throws ModuleException 
     */
//    @SuppressWarnings("deprecation")
    public void insert(Map reqMap, UserObject user) throws ModuleException {
        ErrorInputException eie = null;
        if (user == null) {
            eie = getErrorInputException(eie, "�ϥΪ̸�T���o����");
        }
        if (reqMap == null || reqMap.isEmpty()) {
            throw getErrorInputException(eie, "�򥻸�Ƥ��o����");
        }
        String EMP_ID = MapUtils.getString(reqMap, "EMP_ID");
        if (StringUtils.isBlank(EMP_ID)) {
            eie = getErrorInputException(eie, "���u�s�����o����");
        }
        String BIRTHDAY = MapUtils.getString(reqMap, "BIRTHDAY");
        if (StringUtils.isNotBlank(BIRTHDAY) && !DATE.isDate(BIRTHDAY)) {
            eie = getErrorInputException(eie, "�ͤ����榡���~");
        }
        if (eie != null) {
            throw eie;
        }
        String empID = user.getEmpID();

        String FLOW_NO = new RZ_N0Z001().startFlow("XXZX0101", "�s�W", "", empID, user.getDivNo());

        DataSet ds = Transaction.getDataSet();
        ds.setField("EMP_ID", EMP_ID);
        ds.setField("EMP_NAME", reqMap.get("EMP_NAME"));
        ds.setField("DIV_NO", reqMap.get("DIV_NO"));
        ds.setField("BIRTHDAY", BIRTHDAY);
        ds.setField("POSITION", reqMap.get("POSITION"));
        ds.setField("UPDT_ID", empID);
        ds.setField("UPDT_DATE", DATE.currentTime());
        ds.setField("OP_STATUS", 10);
        ds.setField("FLOW_NO", FLOW_NO);
        DBUtil.executeUpdate(ds, SQL_insert_001);
        //DBUtil.searchAndRetrieve(ds, sqlKey)
        //DATE.getDBTimeStamp();
        //DATE.today();

    }

    /**
     * ��s�򥻸��
     * @param reqMap
     * @param user
     * <pre>
     * ��s�򥻸��
     * EMP_ID�G���u�s��
     * DIV_NO�G���N��
     * EMP_NAME�G���u�m�W
     * BIRTHDAY�G�ͤ���
     * POSITION�G¾��
     * </pre>
     * @return void
     * @throws ModuleException 
     */
    public void update(Map reqMap, UserObject user) throws ModuleException {
        ErrorInputException eie = null;
        if (user == null) {
            eie = getErrorInputException(eie, "�ϥΪ̸�T���o����");
        }
        if (reqMap == null || reqMap.isEmpty()) {
            throw getErrorInputException(eie, "�򥻸�Ƥ��o����");
        }
        String EMP_ID = MapUtils.getString(reqMap, "EMP_ID");
        if (StringUtils.isBlank(EMP_ID)) {
            eie = getErrorInputException(eie, "���u�s�����o����");
        }
        String BIRTHDAY = MapUtils.getString(reqMap, "BIRTHDAY");
        System.err.println("BIRTHDAY:"+BIRTHDAY);
        if (StringUtils.isNotBlank(BIRTHDAY) && !DATE.isDate(BIRTHDAY)) {
            eie = getErrorInputException(eie, "�ͤ����榡���~");
        }else{
            BIRTHDAY = null;
        }
        if (eie != null) {
            throw eie;
        }
        String empID = user.getEmpID();

//        Timestamp currentTimestamp = new java.sql.Timestamp(Calendar.getInstance().getTime().getTime());
         
        DataSet ds = Transaction.getDataSet();
        ds.setField("EMP_ID", EMP_ID);
        ds.setField("BIRTHDAY", BIRTHDAY);
        ds.setField("EMP_NAME", reqMap.get("EMP_NAME"));
        ds.setField("DIV_NO", reqMap.get("DIV_NO"));
        ds.setField("POSITION", reqMap.get("POSITION"));
        ds.setField("UPDT_ID", empID);
        ds.setField("UPDT_DATE",  DATE.currentTime() );  //DATE.currentTime()
        DBUtil.executeUpdate(ds, SQL_update_001);
    }

    /**
     * �R�����u�򥻸��
     * @param reqMap
     * @param user
     * <pre>
     * �R�����u�򥻸��
     * EMP_ID�G���u�s��
     * </pre>
     * @return void
     * @throws ModuleException 
     */
    public void delete(String EMP_ID) throws ModuleException {
        ErrorInputException eie = null;
        if (EMP_ID == null) {
            eie = getErrorInputException(eie, "�ϥΪ̸�T���o����");
        }
        if (eie != null) {
            throw eie;
        }

        DataSet ds = Transaction.getDataSet();
        ds.setField("EMP_ID", EMP_ID);
        DBUtil.executeUpdate(ds, SQL_delete_001);
    }

    /**
     * ����
     * @param reqMap
     * @param user
     * <pre>
     * ����
     * DTXXTP01�G���u��
     * </pre>
     * @return void
     * @throws ModuleException 
     */
    public void confirm(DTXXTP01 vo) throws ModuleException {
        if (vo == null) {
            throw new ErrorInputException("���u�ɤ��i����");
        }
        vo.setOP_STATUS(20);
        VOTool.update(vo);
    }

    /**
     * �h�^
     * @param reqMap
     * @param user
     * <pre>
     * �h�^
     * DTXXTP01�G���u��
     * </pre>
     * @return void
     * @throws ModuleException 
     */
    public void reject(DTXXTP01 vo) throws ModuleException {
        if (vo == null) {
            throw new ErrorInputException("���u�ɤ��i����");
        }
        vo.setOP_STATUS(10);
        VOTool.update(vo);
    }

    /**
     * �f��
     * @param reqMap
     * @param user
     * <pre>
     * �f��
     * DTXXTP01�G���u��
     * </pre>
     * @return void
     */
    public void approve(DTXXTP01 vo) throws ModuleException {
        if (vo == null) {
            throw new ErrorInputException("���u�ɤ��i����");
        }
        vo.setOP_STATUS(30);
        VOTool.update(vo);
    }

    /**
     * ���~�T���B�z�A�إ� eie ����
     * @param eie
     * @param errMsg
     * @return
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(errMsg);
        return eie;
    }

}
