package com.cathay.lesson06.game2;

public class RPG {
    public static void main(String[] args) {
        demoSwordsMan();
        demoMagician();
    }

    static void demoSwordsMan() {
        SwordsMan swordsMan = new SwordsMan();
        swordsMan.setName("亞瑟王");
        swordsMan.setLevel(1);
        swordsMan.setBlood(200);

        System.out.printf("劍士: (%s, %d, %d)%n", swordsMan.getName(), swordsMan.getLevel(), swordsMan.getBlood());
        
        showBlood(swordsMan);
    }

    static void demoMagician() {
        Magician magician = new Magician();
        magician.setName("梅林");
        magician.setLevel(1);
        magician.setBlood(100);

        System.out.printf("魔法師: (%s, %d, %d)%n", magician.getName(), magician.getLevel(), magician.getBlood());
        
        showBlood(magician);
    }

    //----- 多型 -----
    static void showBlood(SwordsMan swordsMan) {
        System.out.printf("SwordsMan %s 血量 %d%n", swordsMan.getName(), swordsMan.getBlood());
    }

    static void showBlood(Magician magician) {
        System.out.printf("Magician %s 血量 %d%n", magician.getName(), magician.getBlood());
    }

    /**
     * 多型
     * @param role
     */
    static void showBlood(Role role) {
        System.out.printf("Role %s 血量 %d%n", role.getName(), role.getBlood());
    }
}
