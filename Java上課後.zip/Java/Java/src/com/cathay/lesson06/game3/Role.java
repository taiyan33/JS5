package com.cathay.lesson06.game3;

public class Role {
    /** 角色名稱 */
    private String name;

    /** 角色等級 */
    private int level;

    /** 角色血量 */
    private int blood;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    public int getBlood() {
        return blood;
    }

    public void setBlood(int blood) {
        this.blood = blood;
    }
    
    public void fight() {
        // 子類別要自行定義
    }
    
//    public abstract void fight();
}
