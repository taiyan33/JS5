package com.cathay.lesson06.game3;

public class SwordsMan extends Role {

    @Override
    public void fight() {
        System.out.println("揮劍攻擊");
    }
}
