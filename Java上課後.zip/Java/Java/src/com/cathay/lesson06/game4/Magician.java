package com.cathay.lesson06.game4;

public class Magician extends Role {

    @Override
    public void fight() {
        System.out.println("魔法攻擊");
    }

    public void cure() {
        System.out.println("魔法治療");
    }
    
    public String toString(){
    	return String.format("魔法師: (%s, %d, %d)%n", this.getName(), this.getLevel(), this.getBlood());
    }
}
