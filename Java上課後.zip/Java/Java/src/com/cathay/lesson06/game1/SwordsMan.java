package com.cathay.lesson06.game1;

public class SwordsMan {
    /** 角色名稱 */
    private String name;

    /** 角色等級 */
    private int level;

    /** 角色血量 */
    private int blood;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    public int getBlood() {
        return blood;
    }

    public void setBlood(int blood) {
        this.blood = blood;
    }

    public void fight(){
        System.out.println("揮劍攻擊");
    }
}
