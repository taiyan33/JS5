package com.cathay.lesson10.stream;

import java.io.FileNotFoundException;
import java.io.IOException;

public class Member2Demo {

    /**
     * @param args
     * @throws IOException 
     * @throws FileNotFoundException 
     * @throws ClassNotFoundException 
     */
    public static void main(String[] args) throws FileNotFoundException, IOException, ClassNotFoundException {
        Member2[] members = { new Member2("B1234", "Alice", 18), new Member2("B5678", "John", 25), new Member2("B9876", "Mary", 10) };

        for (Member2 member : members) {
            member.save();
        }

        for (Member2 member : members) {
            System.out.println(Member2.load(member.getNumber()));
        }
    }

}
