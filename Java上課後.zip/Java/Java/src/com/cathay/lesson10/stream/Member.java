package com.cathay.lesson10.stream;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class Member {
    private String number;

    private String name;

    private int age;

    private static final String filePath = System.getProperty("user.dir") + "/src/com/cathay/lesson10/stream/";

    public String getNumber() {
        return number;
    }

    public Member(String number, String name, int age) {
        this.number = number;
        this.name = name;
        this.age = age;
    }

    @Override
    public String toString() {
        return String.format("(%s, %s, %d)", number, name, age);
    }

    public void save() throws FileNotFoundException, IOException {
        try (DataOutputStream output = new DataOutputStream(new FileOutputStream(filePath + number + ".txt"))) {
            output.writeUTF(number);
            output.writeUTF(name);
            output.writeInt(age);
        }
    }

    public static Member load(String number) throws FileNotFoundException, IOException {
        Member member;
        try (DataInputStream input = new DataInputStream(new FileInputStream(filePath + number + ".txt"))) {
            member = new Member(input.readUTF(), input.readUTF(), input.readInt());
        }

        return member;
    }

    /**
     * @param args
     */
    public static void main(String[] args) {

    }

}
