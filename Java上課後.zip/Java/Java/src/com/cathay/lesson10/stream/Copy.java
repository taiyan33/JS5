package com.cathay.lesson10.stream;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class Copy {

    /**
     * @param args
     */
    public static void main(String[] args) {
        try {//System.getProperty("user.dir")當下資料夾位置
            String filePath = System.getProperty("user.dir") + "/src/com/cathay/lesson10/stream/";
            IO.dump(new FileInputStream(filePath + "encode_text.txt"), new FileOutputStream(filePath + "encode_text_copy.txt"));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
