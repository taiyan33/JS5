package com.cathay.lesson10.stream;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

public class Member2 implements Serializable {
    private String number;

    private String name;

    private int age;

    private static final String filePath = System.getProperty("user.dir") + "/src/com/cathay/lesson10/stream/";

    public String getNumber() {
        return number;
    }

    public Member2(String number, String name, int age) {
        this.number = number;
        this.name = name;
        this.age = age;
    }

    @Override
    public String toString() {
        return String.format("(%s, %s, %d)", number, name, age);
    }

    public void save() throws FileNotFoundException, IOException {
        try (ObjectOutputStream output = new ObjectOutputStream(new FileOutputStream(filePath + number + ".txt"))) {
            output.writeObject(this);
        }
    }

    public static Member2 load(String number) throws FileNotFoundException, IOException, ClassNotFoundException {
        Member2 member;
        try (ObjectInputStream input = new ObjectInputStream(new FileInputStream(filePath + number + ".txt"))) {
            member = (Member2) input.readObject();
        }

        return member;
    }

    /**
     * @param args
     */
    public static void main(String[] args) {

    }

}
