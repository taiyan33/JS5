package com.cathay.lesson10.stream;

import java.io.FileNotFoundException;
import java.io.IOException;

public class MemberDemo {

    /**
     * @param args
     * @throws IOException 
     * @throws FileNotFoundException 
     */
    public static void main(String[] args) throws FileNotFoundException, IOException {
        Member[] members = { new Member("B1234", "Alice", 18), new Member("B5678", "John", 25), new Member("B9876", "Mary", 10) };

        for (Member member : members) {
            member.save();
        }

        for (Member member : members) {
            System.out.println(Member.load(member.getNumber()));
        }
    }

}
