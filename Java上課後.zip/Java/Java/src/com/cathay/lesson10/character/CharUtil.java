package com.cathay.lesson10.character;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Reader;
import java.io.Writer;
import java.text.DateFormat;

public class CharUtil {
    public static void dump(Reader src, Writer dest) throws IOException {
        try (Reader input = src; Writer output = dest) {
            char[] data = new char[1024];
            int length;
            while ((length = input.read(data)) != -1) {
                output.write(data, 0, length);
            }
        }
    }
}
