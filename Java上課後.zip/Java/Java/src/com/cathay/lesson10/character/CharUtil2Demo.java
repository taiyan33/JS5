package com.cathay.lesson10.character;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class CharUtil2Demo {

    /**
     * @param args
     * @throws IOException 
     * @throws FileNotFoundException 
     */
    public static void main(String[] args) throws FileNotFoundException, IOException {
        String filePath = System.getProperty("user.dir") + "/src/com/cathay/lesson10/character/";
        CharUtil2.dump(new FileInputStream(filePath + "CharUtil2.java"), new FileOutputStream(filePath + "CharUtil2.txt"), "UTF-8");
    }

}
