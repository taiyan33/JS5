package com.cathay.lesson09.collection;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

class Account2 implements Comparable<Account2> {
    private String name;

    private String number;

    private int balance;

    public Account2(String name, String number, int balance) {
        this.name = name;
        this.number = number;
        this.balance = balance;
    }

    @Override
    public String toString() {
        return String.format("Account(%s, %s, %d)", name, number, balance);
    }

    @Override
    public int compareTo(Account2 o) {
        return this.balance - o.balance;
    }
}

public class Sort3 {

    /**
     * @param args
     */
    public static void main(String[] args) {
        List accounts = Arrays.asList(new Account2("Alice", "001", 1000), new Account2("John", "002", 500),
            new Account2("Mary", "003", 200));
        Collections.sort(accounts);

        System.out.println(accounts);
    }
}
