package com.cathay.lesson09.collection;

import java.util.ArrayDeque;
import java.util.Arrays;
import java.util.Collection;
import java.util.Deque;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

public class ForEach {
    public static void main(String[] args) {
        List names_List = Arrays.asList("Alice", "John", "Mary");
        Set names_Set = new HashSet(names_List);
        Deque names_Deque = new ArrayDeque(names_List);
        
        // 輸出Collection的值
        forEach(names_List);
    }
    
//    static void forEach(Collection collection) {
//        System.out.println("### forEach(Collection) ###");
//        Iterator iterator = collection.iterator();
//        while(iterator.hasNext()){
//            System.out.println(iterator.next());
//        }
//    }
    
    static void forEach(Iterable iterable) { //泛型
        System.out.println("### forEach(Iterable) ###");
        Iterator iterator = iterable.iterator();
        while(iterator.hasNext()){
            System.out.println(iterator.next());
        }

        System.out.println("###### 增強式for迴圈 ######");
        for (Object object : iterable) {
            System.out.println(object);
        }
    }
}
