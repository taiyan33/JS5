package com.cathay.lesson09.collection;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

class Account {
    private String name;

    private String number;

    private int balance;

    public Account(String name, String number, int balance) {
        this.name = name;
        this.number = number;
        this.balance = balance;
    }

    @Override
    public String toString() {
        return String.format("Account(%s, %s, %d)", name, number, balance);
    }
}

public class Sort2 {

    /**
     * @param args
     */
    public static void main(String[] args) {
        List accounts = Arrays.asList(new Account("Alice", "001", 1000), new Account("John", "002", 500), new Account("Mary", "003", 200));
        Collections.sort(accounts);

        System.out.println(accounts);
    }
}
