package com.cathay.lesson07.oceanworld1;

public class Human extends Fish {	// 	人 is a 魚???

	public Human(String name) {
		super(name);
	}
	
	@Override
	public void swim() {
		System.out.printf("人 %s 游泳%n", name);
	}
}
