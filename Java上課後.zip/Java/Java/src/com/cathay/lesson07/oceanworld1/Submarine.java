package com.cathay.lesson07.oceanworld1;

public class Submarine extends Fish {	// 	潛水艇 is a 魚???

	public Submarine(String name) {
		super(name);
	}
	
	@Override
	public void swim() {
		System.out.printf("潛水艇 %s 潛行%n", name);
	}
}
