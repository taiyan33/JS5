package com.cathay.lesson07.oceanworld1;

public abstract class Fish {
	protected String name;
	
	public Fish(String name){
		this.name = name;
	}
	
	public String getName(){
		return name;
	}
	
	public abstract void swim();
}
