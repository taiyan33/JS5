package com.cathay.lesson07.oceanworld3;

public interface Flyer {
	public abstract void fly();
}
