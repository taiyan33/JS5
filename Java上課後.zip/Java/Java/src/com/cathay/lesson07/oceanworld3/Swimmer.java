package com.cathay.lesson07.oceanworld3;

public interface Swimmer {
	public abstract void swim();
}
