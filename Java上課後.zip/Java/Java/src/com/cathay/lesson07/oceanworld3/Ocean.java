package com.cathay.lesson07.oceanworld3;

public class Ocean {

	public static void main(String[] args) {
		doSwim(new Seaplane("協和號"));
		doSwim(new FlyingFish("達悟"));
	}
	
	static void doSwim(Swimmer swimmer){
		swimmer.swim();
	}
}
