package com.cathay.lesson07.oceanworld2;

public abstract class Fish implements Swimmer{
	protected String name;
	
	public Fish(String name){
		this.name = name;
	}
	
	public String getName(){
		return name;
	}
	
	@Override
	public abstract void swim();
}
