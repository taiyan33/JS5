package com.cathay.lesson07.oceanworld2;

public class Ocean {

	public static void main(String[] args) {
		doSwim(new Anemonefish("尼莫"));
		doSwim(new Shark("蘭尼"));
		doSwim(new Human("菲爾普斯"));
		doSwim(new Submarine("U571"));
	}
	
	static void doSwim(Swimmer swimmer){
		swimmer.swim();
	}
}
