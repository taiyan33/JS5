package com.cathay.lesson07.oceanworld2;

public interface Swimmer {
	public abstract void swim();
}
