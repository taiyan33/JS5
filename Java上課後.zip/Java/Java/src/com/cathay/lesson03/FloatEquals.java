package com.cathay.lesson03;

public class FloatEquals {

	public static void main(String[] args) {
		System.err.println((1 - 0.8) == 0.2);
		System.err.println("1-0.8 = " + (1.0 - 0.8));
		
		try {
			Class c = Class.forName("com.cathay.lesson05.CashCard");
			Object a = c.newInstance();
			System.err.println(a);
			
		} catch (ClassNotFoundException | IllegalAccessException | InstantiationException e) {
			// TODO 自動產生 catch 區塊
			e.printStackTrace();
		}
        //---------------------------------------
	}
}



//(Math.abs(1-0.8)-0.2) <0.00000001