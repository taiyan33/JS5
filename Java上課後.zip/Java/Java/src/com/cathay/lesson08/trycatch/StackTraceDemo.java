package com.cathay.lesson08.trycatch;

public class StackTraceDemo {

	public static void main(String[] args) {
		try {
			c();
		} catch (NullPointerException e) {
			e.printStackTrace();
		}
	}

	static void c() {
		try {
			b();
		} catch (NullPointerException e) {
			System.err.println("C Exception");
			e.printStackTrace();
//			throw e;
			Throwable t = e.fillInStackTrace();
//			throw (NullPointerException) t;
			throw new NullPointerException("12312312313");
		}
	}

	static void b() {
		a();
	}

	static String a() {
		String text = null;
		return text.toUpperCase();//程式錯誤點
	}
}
