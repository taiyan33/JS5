package com.cathay.practice.lesson06;

import java.util.Scanner;

public class GuassNum {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO 自動產生方法 Stub
		Scanner scanner = new Scanner(System.in);
		int num1 = scanner.nextInt();
		int num = (int)(Math.random()*10);
		while(num!=num1){
			
			
			System.out.println("wrong"+num);
			num1 = scanner.nextInt();
			
		}
		System.out.println("right");
	}

}
