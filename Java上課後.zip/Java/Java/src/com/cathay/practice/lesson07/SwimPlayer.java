package com.cathay.practice.lesson07;

public class SwimPlayer extends Human //有繼承介面// implements Swimmer 
{


//	private String name;

	public SwimPlayer(String name) {
		super(name);
//		this.name = name;
	}

	//繼承父類別
//	public String getName() {
//		return super.getName();
//		return name;
//	}

	@Override
	public void swim() {
		System.out.printf("人 %s 游泳%n", super.getName());
	}



}
