package com.cathay.practice.lesson07;

public class Ocean {

	public static void main(String[] args) {
		doSwim(new Human("一般人"));
		doSwim(new SwimPlayer("潛水員"));
		doSwim(new Seaplane("空陸飛機"));
		
		doFly(new Seaplane("空陸飛機"));
		doFly(new Helicopter("直升機"));
	}
	
	static void doSwim(Swimmer s){
			s.swim();
	}
	
	static void doFly(Flyer f){
		f.fly();
	}
}
