package com.cathay.practice.lesson07;

public interface Swimmer {
	public abstract void swim();
}
