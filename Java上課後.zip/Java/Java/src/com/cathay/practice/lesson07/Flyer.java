package com.cathay.practice.lesson07;

public interface Flyer {
	public abstract void fly();
}
