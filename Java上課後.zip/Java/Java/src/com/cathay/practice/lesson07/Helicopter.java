package com.cathay.practice.lesson07;

public class Helicopter implements Flyer {
	private String name;
	
	public Helicopter(String name) {
		this.name = name;
	}
	/**
	 * @param args
	 */
	@Override
	public void fly() {
		System.out.printf("直升機 %s 在飛%n", name);
	}

}
