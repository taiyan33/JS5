package com.cathay.practice.lesson08;

/**
 * 儲值卡
 */
public class CashCard {
	/** 儲值卡號碼 */
	String number;

	/** 餘額 */
	int balance;

	/** 紅利 */
	int bonus;

	/**
	 * 儲值
	 * @param money
	 */
	public void store(int money) {
		if (money > 0) {
			this.balance += money;
			if (money >= 1000) {
				this.bonus++;
			}
		} else {
			System.err.println("儲值是負的！");
		}
	}

	/**
	 * 扣款
	 * @param money
	 */
	public void charge(int money) {
		if (money > 0) {
			if (money <= this.balance) {
				this.balance -= money;
			} else {
				System.err.println("餘額不足！");
			}
		} else {
			System.err.println("扣負數？要送我錢嗎？");
		}
	}

	/**
	 * 兌換紅利
	 * @param bonus
	 */
	public int exchange(int bonus) {
		if (bonus > 0) {
			this.bonus -= bonus;
		}
		return this.bonus;
	}

	public CashCard() {

	}

	public CashCard(String number, int balance, int bonus) {
		this.number = number;
		this.balance = balance;
		this.bonus = bonus;
	}
}
