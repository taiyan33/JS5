package com.cathay.lesson05;

/**
 * 儲值卡
 */
public class CashCard {
    /** 儲值卡號碼 */
    private String number;

    /** 餘額 */
    private int balance;

    /** 紅利 */
    private int bonus;

    public void setBalance(int money) {
        if (money > 0) {
            this.balance += money;
            if (money >= 1000) {
                this.bonus++;
            }
        } else {
            System.err.println("儲值是負的！");
        }
    }
    
    public void setBalance(Integer money) {
        if (money > 0) {
            this.balance += money;
            if (money >= 1000) {
                this.bonus++;
            }
        } else {
            System.err.println("儲值是負的！");
        }
    }

//    public CashCard() {
//    	System.out.println("start"); //new 
//    }

    public CashCard(String number, int balance, int bonus) {
//		this(); //new 
        this.number = number;
        this.balance = balance;
        this.bonus = bonus;
    }
}
