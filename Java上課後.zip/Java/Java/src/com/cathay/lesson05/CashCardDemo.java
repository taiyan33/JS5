package com.cathay.lesson05;

import java.util.Scanner;

public class CashCardDemo {
    public static void main(String[] args) {
        boolean isNotEncapsulation = true;
        if (isNotEncapsulation) {
            // 未封裝
//            CashCard card1 = new CashCard();
//            card1.number = "A001";
//            card1.balance = 500;
//            card1.bonus = 0;

//            CashCard card2 = new CashCard();
//            card2.number = "A002";
//            card2.balance = 300;
//            card2.bonus = 0;

//            CashCard card3 = new CashCard();
//            card3.number = "A003";
//            card3.balance = 1000;
//            card3.bonus = 1;

            //---------------------------------------
        	
            Scanner scanner = null;
            try {
                scanner = new Scanner(System.in);
                int money = scanner.nextInt();
                if (money > 0) {
//                    card1.setBalance( money); 
//                    card1.sebalance += money;
                    if (money >= 1000) {
//                        card1.bonus++;
                    }
                } else {
                    System.err.println("儲值是負的！");
                }
            } finally {
                if (scanner != null) {
                    scanner.close();
                }
            }
        } else {
            // 使用建構式，實現了物件初始化流程的封裝
            CashCard card1 = new CashCard("A001", 500, 0);
            CashCard card2 = new CashCard("A002", 300, 0);
            CashCard card3 = new CashCard("A003", 1000, 1);

            Scanner scanner = null;
            try {
                scanner = new Scanner(System.in);
                int money = scanner.nextInt();

                // 封裝了儲值的流程
                card1.setBalance(money);
//                card1.balance = money;
            } finally {
                if (scanner != null) {
                    scanner.close();
                }
            }
        }
    }
}
