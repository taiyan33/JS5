package com.cathay.lesson05;

public class VariableLengthArg {

	public static void main(String[] args) {
		output("A", "B", "C", "D");
		System.out.println("");
		output("A", "B", "C");
	}
	
	public static void output(String... args){
		for(String s:args){
			System.out.printf("%s ", s);
		}
	}
}
