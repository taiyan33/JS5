package com.cathay.lesson04;

public class IntegerEquals {

	public static void main(String[] args) {
		if (true) {
			Integer int1 = 100;
			Integer int2 = 100;

			if (int1 == int2) {
				System.out.println("int1 == int2");
			} else {
				System.err.println("int1 != int2");
			}
		} else {
			Integer int1 = 200;
			Integer int2 = 200;

			if (int1 == int2) {
				System.out.println("int1 == int2");
			} else {
				System.err.println("int1 != int2");
			}
		}
	}
}
